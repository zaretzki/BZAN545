rzaretzk_carbo_loading-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema rzaretzk_carbo_loading
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema rzaretzk_carbo_loading
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `rzaretzk_carbo_loading` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
USE `rzaretzk_carbo_loading` ;

-- -----------------------------------------------------
-- Table `rzaretzk_carbo_loading`.`dh_product_lookup`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `rzaretzk_carbo_loading`.`dh_product_lookup` ;

CREATE TABLE IF NOT EXISTS `rzaretzk_carbo_loading`.`dh_product_lookup` (
  `upc` BIGINT NOT NULL,
  `product_description` VARCHAR(100) NULL,
  `commodity` VARCHAR(45) NULL,
  `brand` VARCHAR(45) NULL,
  `product_size` VARCHAR(45) NULL,
  PRIMARY KEY (`upc`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `rzaretzk_carbo_loading`.`dh_causal_lookup`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `rzaretzk_carbo_loading`.`dh_causal_lookup` ;

CREATE TABLE IF NOT EXISTS `rzaretzk_carbo_loading`.`dh_causal_lookup` (
  `upc` BIGINT NOT NULL,
  `week` INT NOT NULL,
  `store` INT NOT NULL,
  `feature_desc` VARCHAR(100) NULL,
  `display_desc` VARCHAR(100) NULL,
  `geography` INT NULL,
  `causal_key` INT NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`causal_key`))
ENGINE = InnoDB;

CREATE INDEX `week` ON `rzaretzk_carbo_loading`.`dh_causal_lookup` (`week` ASC);

CREATE INDEX `upc` ON `rzaretzk_carbo_loading`.`dh_causal_lookup` (`store` ASC);

-- -----------------------------------------------------
-- Table `rzaretzk_carbo_loading`.`dh_store_lookup`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `rzaretzk_carbo_loading`.`dh_store_lookup` ;

CREATE TABLE IF NOT EXISTS `rzaretzk_carbo_loading`.`dh_store_lookup` (
  `store` INT NOT NULL,
  `store_zip_code` VARCHAR(45) NULL,
  PRIMARY KEY (`store`))
ENGINE = InnoDB;

CREATE INDEX `zip` ON `rzaretzk_carbo_loading`.`dh_store_lookup` (`store_zip_code` ASC);


-- -----------------------------------------------------
-- Table `rzaretzk_carbo_loading`.`dh_transactions`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `rzaretzk_carbo_loading`.`dh_transactions` ;

CREATE TABLE IF NOT EXISTS `rzaretzk_carbo_loading`.`dh_transactions` (
  `upc` BIGINT NOT NULL,
  `dollar_sales` DECIMAL(12,2) NULL,
  `units` INT NULL,
  `time_of_transaction` TIME NOT NULL,
  `geography` INT NULL,
  `week` INT NULL,
  `household` INT NOT NULL,
  `store` INT NULL,
  `basket` INT NULL,
  `day` INT NOT NULL,
  `coupon` INT NULL,
  `transactions_key` INT NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`transactions_key`))
ENGINE = InnoDB;

CREATE INDEX `week` ON `rzaretzk_carbo_loading`.`dh_transactions` (`week` ASC);

CREATE INDEX `store` ON `rzaretzk_carbo_loading`.`dh_transactions` (`store` ASC);

CREATE INDEX `day` ON `rzaretzk_carbo_loading`.`dh_transactions` (`day` ASC);

CREATE INDEX `upc` ON `rzaretzk_carbo_loading`.`dh_transactions` (`upc` ASC);


-- -----------------------------------------------------
-- Table `rzaretzk_carbo_loading`.`dh_transactions`
-- -----------------------------------------------------

CREATE TABLE IF NOT EXISTS `rzaretzk_carbo_loading`.`dh_transactions_noind` (
  `upc` BIGINT NOT NULL,
  `dollar_sales` DECIMAL(12,2) NULL,
  `units` INT NULL,
  `time_of_transaction` TIME NOT NULL,
  `geography` INT NULL,
  `week` INT NULL,
  `household` INT NOT NULL,
  `store` INT NULL,
  `basket` INT NULL,
  `day` INT NOT NULL,
  `coupon` INT NULL,
  `transactions_key` INT NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`transactions_key`))
ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS `rzaretzk_carbo_loading`.`dh_causal_lookup_noind` (
  `upc` BIGINT NOT NULL,
  `week` INT NOT NULL,
  `store` INT NOT NULL,
  `feature_desc` VARCHAR(100) NULL,
  `display_desc` VARCHAR(100) NULL,
  `geography` INT NULL,
  `causal_key` INT NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`causal_key`))
ENGINE = InnoDB;





SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

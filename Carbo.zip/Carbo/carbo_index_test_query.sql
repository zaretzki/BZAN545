CREATE INDEX upc on dh_causal_lookup(upc);
CREATE INDEX week on dh_causal_lookup(week);
CREATE INDEX store on dh_causal_lookup(store);


select b.feature_desc, b.display_desc, a.household as household, a.dollar_sales as sales, a.units as units, a.week as week
from dh_transactions as a, dh_causal_lookup as b
where a.upc = b.upc
and a.week = b.week
and a.store = b.store
and b.week between 45 and 50
Limit 40000;

INTO OUTFILE "c:/users/testq1.csv"
FIELDS TERMINATED BY ',' 
LINES TERMINATED BY '\n';

select b.feature_desc, b.display_desc, a.household as household, a.dollar_sales as sales, a.units as units, a.week as week
from dh_transactions_noind as a, dh_causal_lookup_noind as b
where a.upc = b.upc
and a.week = b.week
and a.store = b.store
and b.week between 45 and 50
Limit 40000;


select upc into @aid
from dh_transactions
group by upc
order by count(upc)
desc limit 1;
 
 select upc, feature_desc, display_desc, week
 from dh_causal_lookup
 where upc = @aid;
 
 select @aid;
 
 select *
 from dh_product_lookup
 where upc = @aid;
 

